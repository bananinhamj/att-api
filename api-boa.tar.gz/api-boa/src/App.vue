<script>
import MenuLateral from "@/components/MenuLateral.vue";
import CabecalhoComp from "@/components/CabecalhoComp.vue";
import PrincipalComp from "@/components/PrincipalComp.vue";
import RodapeComp from "@/components/RodapeComp.vue";
export default {
  components: { MenuLateral, CabecalhoComp, PrincipalComp, RodapeComp },
};
</script>
<template>
  <MenuLateral />
  <CabecalhoComp />
  <PrincipalComp />
  <RodapeComp />
</template>
<style></style>
