<script>
export default {};
</script>
<template>
  <article class="block">
    <img class="extraordinaria" src="@/assets/img/extraordinaria.jpg" />
    <p></p>
  </article>
</template>
<style>
.extraordinaria {
  width: 300px;
  height: 400px;
  border-radius: 15px;
}
</style>
