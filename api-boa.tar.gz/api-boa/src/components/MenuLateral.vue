<script>
export default {};
</script>
<template>
  <aside id="sidenav">
    <p class="lateral">Terror</p>
    <p class="lateral">Drama</p>
    <p class="lateral">Comédia</p>
    <p class="lateral">Romance</p>
    <p class="lateral">Ficção cientifica</p>
  </aside>
</template>
<style></style>
