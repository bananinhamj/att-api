<script>
export default {};
</script>
<template>
  <header id="header">
    <img class="logo" src="@/assets/img/K(1).png.jpg">
    <h1 class="titulo">Kdramabook</h1>
    <div>
      <div id="divBusca">
        <input type="text" id="txtBusca" placeholder="Drama...." />
      </div>
      <div id="divBotao">
        <button type="button" id="botao" placeholder="pesquisar">
          Pesquisar
        </button>
      </div>
    </div>
  </header>
</template>
<style></style>
