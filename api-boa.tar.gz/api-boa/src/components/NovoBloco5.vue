<script>
export default {};
</script>
<template>
  <article class="block">
    <p></p>
  </article>
</template>
